/* common */
function fillZero(width, str) {
  return str.length >= width ? str : new Array(width - str.length + 1).join('0') + str;//남는 길이만큼 0으로 채움
}
// main top visual slide
const mainTopVisualSlide = new Swiper('.main-top-visual .top-visual.swiper-container', {
  updateOnWindowResize: true,
  speed: 500,
  pagination: {
    el: '.swiper-pagination',
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
});
// main top notice
const mainTopNoticelSlide = new Swiper('.top-notice .swiper-container', {
  updateOnWindowResize: true,
  speed: 1000,
  effect: "fade",
  slidesPerView: 1,
  autoplay: {
    delay: 3000,
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
});
// main ticket slide
const mainCalendarTicketSlide = new Swiper('.game-calendar .date-list .swiper-container', {
  updateOnWindowResize: true,
  slidesPerView: 'auto',
  freeMode: {
    enabled: true,
    sticky: true,
  },
});
const mainTicketSlide = new Swiper('.game-slide .swiper-container', {
  updateOnWindowResize: true,
  speed: 500,
  pagination: {
    el: '.swiper-pagination',
  },
  navigation: {
    nextEl: '.swiper-button-next.outside',
    prevEl: '.swiper-button-prev.outside',
  },
});
// main shop popular slide
const mainShopPopularSlide = new Swiper('.shop-zone.popular .tab.swiper-container', {
  // updateOnWindowResize: true,
  speed: 300,
  freeMode: {
    enabled: true,
    sticky: true,
  },
  slidesPerView: "auto",
});
// main shop discount slide
const mainShopDiscountSlide = new Swiper('.shop-zone.discount:not(.wide) .swiper-container', {
  updateOnWindowResize: true,
  speed: 300,
  slidesPerView: "auto",
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
});
const mainShopDiscountSlideWide = new Swiper('.shop-zone.discount.wide .swiper-container', {
  updateOnWindowResize: true,
  speed: 300,
  slidesPerView: 4,
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
});
// 인기샵 슬라이드
const mainPopularShopSlide = new Swiper('.shop-zone.popular-shop .swiper-container', {
  // updateOnWindowResize: true,
  speed: 300,
  slidesPerView: "auto",
  freeMode: {
    enabled: true,
    sticky: true,
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
});
// main event slide
const maineventSlide = new Swiper('.play-zone.event .event-list.swiper-container', {
  updateOnWindowResize: true,
  effect: "fade",
  fadeEffect: {
    crossFade: true
  },
  autoHeight: true,
  speed: 300,
  slidesPerView: "auto",
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
    renderBullet: function (index, className) {
      return '<span class="' + className + '">' + ((index + 1).toString().padStart(2, '0')) + "</span>";
    },
  },
  on: {
    afterInit: function () {
      console.log((this.activeIndex + 1) + "/" + this.slides.length)
      $(this.$el).find('.swiper-progress .progress').css({
        'width': (100 * ((this.activeIndex + 1) / this.slides.length)) + "%"
      })
    },
    activeIndexChange: function () {
      console.log((this.activeIndex + 1) + "/" + this.slides.length)
      $(this.$el).find('.swiper-progress .progress').css({
        'width': (100 * ((this.activeIndex + 1) / this.slides.length)) + "%"
      })
      // console.log($(this.$el).find('.swiper-progress .progress'))
    }
  }

  // Navigation arrows  
});


// common tab init
$.fn.initTabs = function () {
  console.log(this);
  let tabLinkGroup = $(this).find('> .tab');
  let tabTarget = $(this).find('> .tab-content');
  tabLinkGroup.find('li').on('click', function () {
    let index = tabLinkGroup.find('li').index(this);
    console.log('activeTab' + index);
    tabTarget.hide();
    tabTarget.eq(index).show();
  });
}
$(function () {
  /* main shop tabs */
  $('.tabs').each(function () {
    $(this).initTabs();
  });
  /* 스크롤 내리면 위로가기 버튼 보이기 */
  $('.wrapper').on('scroll', function () {
    if ($('.wrapper').scrollTop() >= 200) {
      $(document).find('.btn-top').addClass('show');
    } else {
      $(document).find('.btn-top').removeClass('show');
    }
  });
  /* 탑버튼 누르면 스크롤 위로 올리기 */
  $(document).find('.btn-top').on('click', function () {
    $('.wrapper').scrollTo(0, 500);
  });
  /* 신상품/추천상품 탭 높이 브라우저 사이즈에 맞게 재조절 */
  /* PC only */
  if ($(window).width() > 1024) {

  }
  /* Mo only */
  else {

  }
})