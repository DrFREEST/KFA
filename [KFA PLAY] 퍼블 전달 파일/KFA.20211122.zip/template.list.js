$(function () {
  var page_length = $('.guide_table tbody tr:not(.complete-ignore)').length;
  calc_pub_process = function () {
    var pub_ended = 0;
    $('.status').each(function () {
      if ($(this).hasClass('complete') == true) {
        pub_ended = pub_ended + 1;
      } else if ($(this).hasClass('complete-half') == true) {
        pub_ended = pub_ended + 0.5;
      }
    });
    var per_complete = ((pub_ended / page_length) * 100).toFixed(2);
    $('.pub_summary').text('퍼블리싱 진행률 [ ' + pub_ended + ' page / ' + page_length + ' page] ' + per_complete + '% 완료');
  };
  calc_pub_process();
  $('a').each(function () {
    // $(this).attr("target", "_blank");
    $(this).on('click', function () {
      if ($(this).attr('target') != '_blank') {
        console.log($(this).attr('href'));
        console.log($(document).find('iframe'));
        $(document).find('iframe').attr('src', $(this).attr('href'));
        return false;
      }
    });
  });
});
// var fileRoot = "src/main/webapp/WEB-INF/jsp/";
var pub_list = new Vue({
  el: '#listBody',
  data: {
    pageList: [
      { depth1: '메인화면', depth2: '', depth3: '', depth4: '', depth5: '', fileRoot: 'template/', fileName: '01_web_main', fileHash: '', complete: '', note: '', class: '' },

    ],
  },
});
